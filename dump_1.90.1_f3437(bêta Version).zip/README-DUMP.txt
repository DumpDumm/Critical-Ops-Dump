IL2CPP dump report

Inputs:
- libil2cpp.so: ELF64 AArch64 Android, NDK r27c
- global-metadata.dat: IL2CPP metadata magic 0xFAB11BAF
- Metadata version field at offset 0x04 was bitwise-NOT encoded: raw signed value -40
- Applying bitwise NOT gives 39, matching the metadata layout and the dumper's supported v39 parser.

The original uploaded global-metadata.dat was not modified. The decoder was applied to a working copy only.
Il2CppDumper custom build: CLI v3.2.1
Detected Unity: 6000.3.0b1+
Detected IL2CPP: 39

Output:
- dump.cs
- script.json
- stringliteral.json
- il2cpp.h
- DummyDll (138 assemblies)
- IDA helper scripts

Run environment:
- .NET SDK 8.0.428 / runtime 8.0.34
- Mono.Cecil 0.11.6 package supplied; dumper bundle already includes Mono.Cecil.dll
